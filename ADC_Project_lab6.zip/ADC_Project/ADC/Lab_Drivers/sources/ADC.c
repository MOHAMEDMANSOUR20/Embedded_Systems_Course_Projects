
#include "ADC.h"

#if USE_POLLING == 1
	unsigned char eoc = 0;
#endif

void ADC_Init(ADCConfigType* ConfigParamPtr){


/* Enabling ADC and its Clock: */
RCC -> APB2ENR |= (1u<<8);
ADC1 -> CR2 |= (1u<<0);

// Right Data Alignment
ADC1->CR2 &= ~(1u<<11);

// Set clock prescaler to be 0.5
ADC-> CCR &= ~(1U<<16);
ADC-> CCR &= ~(1U<<17);

/* Setting Resolution: */
if((ConfigParamPtr -> res)&(1<<0)){
	// 10-bits res.
	ADC1 -> CR1 |= ( 1u <<24);
}
else{
	// 8-bits res.
	ADC1 -> CR1 &= ~( 1u <<24);
}
if((ConfigParamPtr -> res)&(1<<1)){
	// 6-bits res.
	ADC1 -> CR1 |= ( 1u <<25);
}
else{
	// 12-bits res.
	ADC1 -> CR1 &= ~( 1u <<25);
}


/* Setting Conversion Mode: */
if(ConfigParamPtr -> conv)
	// cont. mode:
	ADC1 -> CR2 |= (1u<<1);
else
	// single mode:
	ADC1 -> CR2 &= ~(1u<<1);

// only one channel in reguler sequence:
ADC1 -> SQR1 &= ~(15u<<20);

// samplining time 480 cycles:
ADC1 ->SMPR2 |= (7u<<0);

}

void ADC_StartConv(unsigned char ChannelNum){

	/* Setting port A to analog mode: */
	if (ChannelNum<8){
		RCC -> AHB1ENR |= (1u<<0);
		GPIOA -> MODER |= (1u << (2*ChannelNum));
		GPIOA -> MODER |= (1u << (2*ChannelNum +1));
		GPIOA -> PUPDR &= ~(1u << (2*ChannelNum));
		GPIOA -> PUPDR &= ~(1u << (2*ChannelNum+1));
	}
	/* Setting port B to analog mode: */
	else if (ChannelNum<10){
		RCC -> AHB1ENR |= (1u<<1);
		GPIOB -> MODER |= (1u << (2*(ChannelNum-8)));
		GPIOB -> MODER |= (1u << (2*(ChannelNum-8) +1));
		GPIOB -> PUPDR &= ~(1u << (2*(ChannelNum-8)));
		GPIOB -> PUPDR &= ~(1u << (2*(ChannelNum-8)+1));
	}
	/* Setting port B to analog mode: */
	else{
		RCC -> AHB1ENR |= (1u<<2);
		GPIOB -> MODER |= (1u << (2*(ChannelNum-10)));
		GPIOB -> MODER |= (1u << (2*(ChannelNum-10) +1));
		GPIOB -> PUPDR &= ~(1u << (2*(ChannelNum-10)));
		GPIOB -> PUPDR &= ~(1u << (2*(ChannelNum-10)+1));
	}

	/* Setting channel as the only channel in regular sequence: */

	ADC1 -> SQR3 |= (ChannelNum<<0);

	/* Starting Conversion: */
	ADC1 -> CR2 |= (1u<<30);


	}

# if USE_POLLING == 1

void ADC_GetConversionState(unsigned char* ConversionStatePtr){
	// reading end of conv. flag:
	unsigned char end_conv = ADC1 -> SR & (1u<<1);
	if (end_conv) * ConversionStatePtr = 1;
	else  * ConversionStatePtr = 0;
}



unsigned char ADC_ReadData(unsigned short int* DataPtr){
	unsigned char *ptr = &eoc;
	ADC_GetConversionState(ptr);
	if(eoc){
		*DataPtr = ADC1 -> DR;
		return 1;
	}
	else return 0;

}
#endif

