/**
  ******************************************************************************
  * @file    main.c
  * @author  Ac6
  * @version V1.0
  * @date    01-December-2013
  * @brief   Default main function.
  ******************************************************************************
*/
#include "GPIO.h"
#include "ADC.h"
#include "LCD.h"
#include "stm32f4xx.h"

unsigned short int data;
unsigned short int *data_ptr = &data;

int main(void)
{
// Setting ADC:
ADCConfigType my_ADC;
my_ADC.res = very_high;
my_ADC.conv = single;
my_ADC.v_ref = 2;

ADCConfigType * my_ADC_ptr = &my_ADC;

// Initialize ADC:
ADC_Init(my_ADC_ptr);

# if USE_POLLING == 0
// Interrupt Enable (ADC):
ADC1 ->CR1 |= (1u<<5);
// Interrupt Enable (NVIC):
NVIC->ISER[0] |= (1u<<18);
#endif

// Initialize LCD:
LCD_Init();
LCD_DisplayString("Warming Up!!!!!");

if (my_ADC.conv == continues)
ADC_StartConv(0u);

while(1){
if (my_ADC.conv == single)
	ADC_StartConv(0u);

# if USE_POLLING == 1
	unsigned char read = ADC_ReadData(data_ptr);
	while(!read){
		// wait until data is read:
		read = ADC_ReadData(data_ptr);
		if(read){
			break;
			}}
#endif

char  temp_value =(unsigned short int) ((unsigned int)(data * 150 *5 )/(1.5*4095) );
LCD_ClearScreen();
LCD_IntToStr(temp_value);

}
}

# if USE_POLLING == 0
void ADC_IRQHandler(void){
	*data_ptr = ADC1 -> DR;
	}
#endif
