<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<?scdStore version="2"?><scannerInfo id="org.eclipse.cdt.make.core.discoveredScannerInfo">
<instance id="fr.ac6.managedbuild.config.gnu.cross.exe.debug.741037586;fr.ac6.managedbuild.config.gnu.cross.exe.debug.741037586.;fr.ac6.managedbuild.tool.gnu.cross.c.compiler.1403228989;fr.ac6.managedbuild.tool.gnu.cross.c.compiler.input.c.1900687163">
<collector id="org.eclipse.cdt.make.core.PerProjectSICollector"/>
</instance>
<instance id="fr.ac6.managedbuild.config.gnu.cross.exe.release.1464441265;fr.ac6.managedbuild.config.gnu.cross.exe.release.1464441265.;fr.ac6.managedbuild.tool.gnu.cross.c.compiler.687239054;fr.ac6.managedbuild.tool.gnu.cross.c.compiler.input.c.1374142114">
<collector id="org.eclipse.cdt.make.core.PerProjectSICollector"/>
</instance>
</scannerInfo>
