src/main.o: ../src/main.c \
 D:/Mohamed/Third_Year/Second_Term/Digital\ Systems\ in\ Medical\ Devices/labs\ projects/ADC_Project/ADC/Lab_Drivers/includes/GPIO.h \
 D:/Mohamed/Third_Year/Second_Term/Digital\ Systems\ in\ Medical\ Devices/labs\ projects/ADC_Project/ADC/CMSIS/device/stm32f4xx.h \
 D:/Mohamed/Third_Year/Second_Term/Digital\ Systems\ in\ Medical\ Devices/labs\ projects/ADC_Project/ADC/CMSIS/core/core_cm4.h \
 D:/Mohamed/Third_Year/Second_Term/Digital\ Systems\ in\ Medical\ Devices/labs\ projects/ADC_Project/ADC/CMSIS/core/core_cmInstr.h \
 D:/Mohamed/Third_Year/Second_Term/Digital\ Systems\ in\ Medical\ Devices/labs\ projects/ADC_Project/ADC/CMSIS/core/core_cmFunc.h \
 D:/Mohamed/Third_Year/Second_Term/Digital\ Systems\ in\ Medical\ Devices/labs\ projects/ADC_Project/ADC/CMSIS/core/core_cmSimd.h \
 D:/Mohamed/Third_Year/Second_Term/Digital\ Systems\ in\ Medical\ Devices/labs\ projects/ADC_Project/ADC/CMSIS/device/system_stm32f4xx.h \
 D:/Mohamed/Third_Year/Second_Term/Digital\ Systems\ in\ Medical\ Devices/labs\ projects/ADC_Project/ADC/Lab_Drivers/includes/ADC.h

D:/Mohamed/Third_Year/Second_Term/Digital\ Systems\ in\ Medical\ Devices/labs\ projects/ADC_Project/ADC/Lab_Drivers/includes/GPIO.h:

D:/Mohamed/Third_Year/Second_Term/Digital\ Systems\ in\ Medical\ Devices/labs\ projects/ADC_Project/ADC/CMSIS/device/stm32f4xx.h:

D:/Mohamed/Third_Year/Second_Term/Digital\ Systems\ in\ Medical\ Devices/labs\ projects/ADC_Project/ADC/CMSIS/core/core_cm4.h:

D:/Mohamed/Third_Year/Second_Term/Digital\ Systems\ in\ Medical\ Devices/labs\ projects/ADC_Project/ADC/CMSIS/core/core_cmInstr.h:

D:/Mohamed/Third_Year/Second_Term/Digital\ Systems\ in\ Medical\ Devices/labs\ projects/ADC_Project/ADC/CMSIS/core/core_cmFunc.h:

D:/Mohamed/Third_Year/Second_Term/Digital\ Systems\ in\ Medical\ Devices/labs\ projects/ADC_Project/ADC/CMSIS/core/core_cmSimd.h:

D:/Mohamed/Third_Year/Second_Term/Digital\ Systems\ in\ Medical\ Devices/labs\ projects/ADC_Project/ADC/CMSIS/device/system_stm32f4xx.h:

D:/Mohamed/Third_Year/Second_Term/Digital\ Systems\ in\ Medical\ Devices/labs\ projects/ADC_Project/ADC/Lab_Drivers/includes/ADC.h:
